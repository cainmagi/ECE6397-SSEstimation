# ECE6397-SSEstimation

The homeworks for the ECE6397, State-space Estimation.

* Homework 1: State-space model.
* Homework 2: Baisc theory of Point Process.

## Update reports

### @ 03/09/20

Update the second homework.

### @ 02/17/20

Create this project.